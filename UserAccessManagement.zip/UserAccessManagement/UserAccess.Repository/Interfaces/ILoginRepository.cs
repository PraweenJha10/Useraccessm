﻿using UserAccess.ViewModel;

namespace UserAccess.Repository.Interfaces
{
    public interface ILoginRepository
    {
        UserViewModel GetUserbyLoginName(string loginName,string password);
    }
}
