﻿using System.Collections.Generic;
using UserAccess.ViewModel;

namespace UserAccess.Repository.Interfaces
{
    public interface IUserRepository
    {
        int AddUser(UserViewModel User);
        bool IsUserExist(string UserName);
        IEnumerable<UserViewModel> GetUsers();
        UserViewModel GetUserbyId(int UserId);
    }
}
