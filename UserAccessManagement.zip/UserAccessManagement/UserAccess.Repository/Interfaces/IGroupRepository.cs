﻿using System.Collections.Generic;
using UserAccess.ViewModel;

namespace UserAccess.Repository.Interfaces
{
    public interface IGroupRepository
    {
        int AddGroup(GroupViewModel group);
        bool IsGroupExist(string GroupName);
        IEnumerable<GroupViewModel> GetGroups();
        GroupViewModel GetGroupbyId(int GroupId);
    }
}
