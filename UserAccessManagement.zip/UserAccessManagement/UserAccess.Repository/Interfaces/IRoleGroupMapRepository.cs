﻿using System.Collections.Generic;
using UserAccess.ViewModel;

namespace UserAccess.Repository.Interfaces
{
    public interface IRoleGroupMapRepository
    {
        int AddupdateRoleGroup(IEnumerable<RoleGroupViewModel> roleGroup);
        int GetUserbyRoleidGroupid(int RoleId, int GroupId);
        IEnumerable<RoleGroupNameViewModel> GetRoleGroupByRoleId(int RoleId);
        IEnumerable<RoleGroupNameViewModel> GetRoleGroupNameByRoleId(int RoleId);
    }
}
