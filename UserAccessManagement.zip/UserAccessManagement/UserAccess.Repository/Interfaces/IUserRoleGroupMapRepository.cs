﻿using System.Collections.Generic;
using UserAccess.ViewModel;

namespace UserAccess.Repository.Interfaces
{
    public interface IUserRoleGroupMapRepository
    {
        IEnumerable<UserRoleViewModel> GetUserRoles();
        int AddUpdateUserRoleGroupMapping(IEnumerable<UserRoleGroupNameViewModel> userRoleGroupViewModel);
        IEnumerable<UserRoleGroupNameViewModel> GetuserRoleGroupNamebyUseridRoleId(int UserId, int RoleId);
        UserRoleGroupAssign GetUserRoleGroupAssignByUserId(int userId);

    }
}
