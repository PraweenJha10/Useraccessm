﻿using System;
using System.Collections.Generic;
using System.Linq;
using UserAccess.Repository.Interfaces;
using UserAccess.Repository.Models;
using UserAccess.ViewModel;

namespace UserAccess.Repository.Implementation
{
    public class RoleRepository : IRoleRepository
    {
        private UserAcessEntities _userAcessEntities;

        public RoleRepository(UserAcessEntities userAcessEntities)
        {
            _userAcessEntities = userAcessEntities;
        }

        public int AddRole(RoleViewModel Role)
        {
            Role createdRole = null;
            Role.CreatedDate = DateTime.Now;
            Role.ModifiedDate = DateTime.Now;
            using (_userAcessEntities)
            {
                createdRole = _userAcessEntities.Roles.Add(new Role { RoleId = Role.RoleId, RoleName = Role.RoleName, CreatedDate = Role.CreatedDate, ModifiedDate=Role.ModifiedDate });
                _userAcessEntities.SaveChanges();
            }
            return createdRole.RoleId;
        }

        public RoleViewModel GetRolebyId(int RoleId)
        {
            RoleViewModel Role;
            using (_userAcessEntities)
            {
                Role = _userAcessEntities.Roles.Where(g => g.RoleId == RoleId).Select(g => new RoleViewModel
                {
                    RoleId = g.RoleId,
                    RoleName = g.RoleName,
                    CreatedDate = g.CreatedDate,
                    ModifiedDate = g.ModifiedDate
                }).FirstOrDefault();
            }
            return Role;
        }

        public IEnumerable<RoleViewModel> GetRoles()
        {
            IEnumerable<RoleViewModel> Roles = null;
            using (_userAcessEntities)
            {
                Roles =  _userAcessEntities.Roles.Select(g => new RoleViewModel
                {
                    RoleId = g.RoleId,
                    RoleName = g.RoleName,
                    CreatedDate = g.CreatedDate,
                    ModifiedDate = g.ModifiedDate
                }).ToList();
            }
            return Roles;
        }

        public bool IsRoleExist(string RoleName)
        {
            using (_userAcessEntities)
            {
                return _userAcessEntities.Roles.Any(g => g.RoleName == RoleName);
            }
        }
    }
}
