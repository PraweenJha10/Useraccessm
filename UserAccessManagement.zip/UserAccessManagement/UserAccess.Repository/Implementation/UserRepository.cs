﻿using System;
using System.Collections.Generic;
using System.Linq;
using UserAccess.Repository.Interfaces;
using UserAccess.Repository.Models;
using UserAccess.ViewModel;

namespace UserAccess.Repository.Implementation
{
    public class UserRepository : IUserRepository
    {
        private UserAcessEntities _userAcessEntities;

        public UserRepository(UserAcessEntities userAcessEntities)
        {
            _userAcessEntities = userAcessEntities;
        }

        public int AddUser(UserViewModel user)
        {
            User createdUser = null;
            user.CreatedDate = DateTime.Now;
            user.ModifiedDate = DateTime.Now;
            using (_userAcessEntities)
            {
                createdUser = _userAcessEntities.Users.Add(new User
                {
                    UserId = user.UserId, UserName = user.UserName, LoginName = user.LoginName,
                    Password = user.Password,UserType = user.UserType, CreatedDate = user.CreatedDate, ModifiedDate= user.ModifiedDate
                });
                _userAcessEntities.SaveChanges();
            }
            return createdUser.UserId;
        }

        public UserViewModel GetUserbyId(int UserId)
        {
            UserViewModel User;
            using (_userAcessEntities)
            {
                User = _userAcessEntities.Users.Where(g => g.UserId == UserId).Select(g => new UserViewModel
                {
                    UserId = g.UserId,
                    UserName = g.UserName,
                    LoginName = g.LoginName,
                    Password = g.Password,
                    UserType = g.UserType,
                    CreatedDate = g.CreatedDate,
                    ModifiedDate = g.ModifiedDate
                }).FirstOrDefault();
            }
            return User;
        }

        public IEnumerable<UserViewModel> GetUsers()
        {
            IEnumerable<UserViewModel> Users = null;
            using (_userAcessEntities)
            {
                Users =  _userAcessEntities.Users.Select(g => new UserViewModel
                {
                    UserId = g.UserId,
                    UserName = g.UserName,
                    LoginName = g.LoginName,
                    Password = g.Password,
                    UserType = g.UserType,
                    CreatedDate = g.CreatedDate,
                    ModifiedDate = g.ModifiedDate
                }).ToList();
            }
            return Users;
        }

        public bool IsUserExist(string UserName)
        {
            using (_userAcessEntities)
            {
                return _userAcessEntities.Users.Any(g => g.LoginName == UserName);
            }
        }
    }
}
