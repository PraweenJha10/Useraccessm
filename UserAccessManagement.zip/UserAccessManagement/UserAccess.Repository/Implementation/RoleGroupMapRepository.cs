﻿using System.Collections.Generic;
using System.Linq;
using UserAccess.Repository.Interfaces;
using UserAccess.Repository.Models;
using UserAccess.ViewModel;

namespace UserAccess.Repository.Implementation
{
    public class RoleGroupMapRepository : IRoleGroupMapRepository
    {
        private UserAcessEntities _userAcessEntities;

        public RoleGroupMapRepository(UserAcessEntities userAcessEntities)
        {
            _userAcessEntities = userAcessEntities;
        }

        public IEnumerable<RoleGroupNameViewModel> GetRoleGroupNameByRoleId(int RoleId)
        {
            using (_userAcessEntities)
            {
                var resulttemp = (from g in _userAcessEntities.Groups
                                  join rgm in _userAcessEntities.RoleGroupMappings on g.GroupId equals rgm.GroupId
                                  where rgm.RoleId == RoleId && rgm.IsActive == true
                                  select new RoleGroupNameViewModel
                                  {
                                      GroupId = g.GroupId,
                                      GroupName = g.GroupName
                                  });

                var result = resulttemp.ToList();

                return result;
            }
        }

        public IEnumerable<RoleGroupNameViewModel> GetRoleGroupByRoleId(int RoleId)
        {
            using (_userAcessEntities)
            {
                var resulttemp = (from g in _userAcessEntities.Groups
                              join rgm in _userAcessEntities.RoleGroupMappings.Where(x=> x.RoleId == RoleId) on g.GroupId equals rgm.GroupId
                              into rgmv
                              from rgm in rgmv.DefaultIfEmpty()
                              select new RoleGroupNameViewModel
                              {
                                  GroupId = g.GroupId,
                                  GroupName = g.GroupName,
                                  IsActive = rgm.IsActive==null?false:rgm.IsActive
                              });

                var result = resulttemp.ToList();

                return result;
            }
        }



        public int AddupdateRoleGroup(IEnumerable<RoleGroupViewModel> rolegroup)
        {
            List<RoleGroupMapping> roleGroupMappings = new List<RoleGroupMapping>();
            int totalRecords = 0;

            foreach (var rolegrp in rolegroup)
            {
                roleGroupMappings.Add(new RoleGroupMapping
                {
                    RoleId = rolegrp.RoleId,
                    GroupId = rolegrp.GroupId,
                    IsActive = rolegrp.IsActive
                });
            }

            using (_userAcessEntities)
            {
                var RoleId = roleGroupMappings[0].RoleId;
                var existingRoleGroup = _userAcessEntities.RoleGroupMappings
                                            .Where(c => c.RoleId == RoleId)
                                            .ToList();

                foreach(var extgrp in existingRoleGroup)
                {
                    extgrp.IsActive = roleGroupMappings.Where(x => x.GroupId == extgrp.GroupId).Select(x => x.IsActive).FirstOrDefault();
                }
               

                var currentRoleGroup = existingRoleGroup
                                            .Where(c => c.RoleId == RoleId)
                                            .Select(x => x.GroupId).ToList();

                foreach (var rg in roleGroupMappings)
                {
                    if (!currentRoleGroup.Contains((int)rg.GroupId))
                        _userAcessEntities.RoleGroupMappings.Add(rg);                                            
                }

                
                _userAcessEntities.SaveChanges();
            }
            return totalRecords;
        }

        public int GetUserbyRoleidGroupid(int RoleId, int GroupId)
        {
            return _userAcessEntities.UserRoleGroupMappings.Where(x => x.RoleId == RoleId && x.GroupId == GroupId).Count();
        }
    }
}
