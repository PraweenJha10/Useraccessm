﻿using System.Collections.Generic;
using System.Linq;
using UserAccess.Repository.Interfaces;
using UserAccess.Repository.Models;
using UserAccess.ViewModel;

namespace UserAccess.Repository.Implementation
{
    public class UserRoleGroupMapRepository : IUserRoleGroupMapRepository
    {
        private UserAcessEntities _userAcessEntities;

        public UserRoleGroupMapRepository(UserAcessEntities userAcessEntities)
        {
            _userAcessEntities = userAcessEntities;
        }



        public IEnumerable<UserRoleViewModel> GetUserRoles()
        {
            using (_userAcessEntities)
            {
                var resulttemp = (from u in _userAcessEntities.Users
                                  join urgm in _userAcessEntities.UserRoleGroupMappings on u.UserId equals urgm.UserId
                                  into urgmv
                                  from urgm in urgmv.DefaultIfEmpty()
                                  join r in _userAcessEntities.Roles on urgm.RoleId equals r.RoleId
                                  into rmp
                                  from r in rmp.DefaultIfEmpty()

                                  select new UserRoleViewModel
                                  {
                                      UserId = u.UserId,
                                      UserName = u.UserName,
                                      RoleId = r.RoleId == null ? 0 : r.RoleId,
                                      RoleName = r.RoleName == null ? "" : r.RoleName,
                                      LoginName = u.LoginName,
                                      UserType = u.UserType
                                  }).Distinct().ToList();
                return resulttemp;
            }

        }


        public IEnumerable<UserRoleGroupNameViewModel> GetuserRoleGroupNamebyUseridRoleId(int UserId, int RoleId)
        {
            return  (from urmp in _userAcessEntities.UserRoleGroupMappings
                         join u in _userAcessEntities.Users on urmp.UserId equals u.UserId
                         join r in _userAcessEntities.Roles on urmp.RoleId equals r.RoleId
                         join g in _userAcessEntities.Groups on urmp.GroupId equals g.GroupId
                         where urmp.UserId == UserId && urmp.RoleId == RoleId
                         select new UserRoleGroupNameViewModel
                         {
                             UserId = urmp.UserId,
                             RoleId = urmp.RoleId,
                             UserName = u.UserName,
                             RoleName = r.RoleName,
                             GroupId = urmp.GroupId,
                             GroupName = g.GroupName,
                             IsActive = urmp.IsActive
                         }).ToList();
        }

        public int AddUpdateUserRoleGroupMapping(IEnumerable<UserRoleGroupNameViewModel> userRoleGroupViewModel)
        {
            List<UserRoleGroupMapping> userroleGroupMappings = new List<UserRoleGroupMapping>();
            int totalRecords = 0;

            foreach (var usrrolegrp in userRoleGroupViewModel)
            {
                userroleGroupMappings.Add(new UserRoleGroupMapping
                {
                    UserId = usrrolegrp.UserId,
                    RoleId = usrrolegrp.RoleId,
                    GroupId = usrrolegrp.GroupId,
                    IsActive = usrrolegrp.IsActive
                });
            }
            var userid = userroleGroupMappings.FirstOrDefault().UserId;


            using (_userAcessEntities)
            {

                _userAcessEntities.UserRoleGroupMappings.RemoveRange(_userAcessEntities.UserRoleGroupMappings.Where(c => c.UserId == userid).ToList());
                _userAcessEntities.SaveChanges();
                _userAcessEntities.UserRoleGroupMappings.AddRange(userroleGroupMappings);
                totalRecords = _userAcessEntities.SaveChanges();


            }

            return totalRecords;
        }

        public UserRoleGroupAssign GetUserRoleGroupAssignByUserId(int userId)
        {
            UserRoleGroupAssign userRoleGroupAssign = new UserRoleGroupAssign();
            using (_userAcessEntities)
            {
                var userData = _userAcessEntities.UserRoleGroupMappings.Where(c => c.UserId == userId).Select(s => s).ToList();
                int roleId = userData.Select(s=>s.RoleId).FirstOrDefault();

                var allGroup = userData.Select(s => new { s.GroupId, s.IsActive }).ToList();

                var allData = (from rgm in _userAcessEntities.RoleGroupMappings
                               join r in _userAcessEntities.Roles on rgm.RoleId equals r.RoleId
                               join g in _userAcessEntities.Groups on rgm.GroupId equals g.GroupId
                               where rgm.RoleId == roleId
                               select new
                               {
                                   rgm.GroupId,
                                   g.GroupName,
                                   r.RoleName
                               }).ToList();
               
                List<GroupViewModel> lstGvm = new List<GroupViewModel>();

                foreach (var item in allData)
                {
                    if (allGroup.Select(s=>s.GroupId).Contains(item.GroupId))
                    {
                        lstGvm.Add(new GroupViewModel { GroupId = item.GroupId, GroupName = item.GroupName, IsActive = allGroup.Where(c=>c.GroupId== item.GroupId).Select(s => s.IsActive).FirstOrDefault() });
                    }
                    else
                    {
                        lstGvm.Add(new GroupViewModel { GroupId = item.GroupId, GroupName = item.GroupName, IsActive = false });
                    }
                }
                //var grouplist = (from urgm in _userAcessEntities.UserRoleGroupMappings
                //                 join rgm in _userAcessEntities.RoleGroupMappings on urgm.RoleId equals rgm.RoleId
                //                 into urgmv
                //                 from p in urgmv.DefaultIfEmpty()
                //                 select new
                //                 {
                //                     urgm.UserId,
                //                     p.GroupId,
                //                     urgm.IsActive,
                //                     p.IsActive
                //                 }).ToList();
                //var result = (from urg in _userAcessEntities.UserRoleGroupMappings
                //               join r in _userAcessEntities.Roles on urg.RoleId equals r.RoleId
                //               join rgm in _userAcessEntities.RoleGroupMappings on r.RoleId equals rgm.RoleId //new { r.RoleId, urg.GroupId } equals new { rgm.RoleId,rgm.GroupId }
                //               into urgm
                //               from urgmv in urgm.DefaultIfEmpty()
                //               join g in _userAcessEntities.Groups on urgmv.GroupId equals g.GroupId
                //               where urg.UserId == userId
                //               select new
                //               {
                //                   UserId = urg.UserId,
                //                   RoleId = urg.RoleId,
                //                   RoleName = r.RoleName,
                //                   GroupId = urg.GroupId,
                //                   GroupName = g.GroupName,
                //                   IsActive = grouplist.Where(x=>x.UserId == urg.UserId && x.GroupId == urg.GroupId).Select(x=> x.IsActive).FirstOrDefault()//urg.IsActive//==null?false: urg.IsActive
                //               }).ToList();

                userRoleGroupAssign.UserId = userData.Select(s => s.UserId).FirstOrDefault();
                userRoleGroupAssign.RoleId = roleId;
                userRoleGroupAssign.RoleName = allData.Select(s => s.RoleName).FirstOrDefault();
                userRoleGroupAssign.Groups = lstGvm;
                //userRoleGroupAssign.Groups = result.Select(s => new GroupViewModel
                //{
                //    GroupId = s.GroupId,
                //    GroupName = s.GroupName,
                //    IsActive = s.IsActive
                //}).ToList();

                return userRoleGroupAssign;
            }
        }
    }
}
