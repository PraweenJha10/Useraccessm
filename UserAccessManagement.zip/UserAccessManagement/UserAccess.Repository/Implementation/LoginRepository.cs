﻿using System.Linq;
using UserAccess.Repository.Interfaces;
using UserAccess.Repository.Models;
using UserAccess.ViewModel;

namespace UserAccess.Repository.Implementation
{
    public class LoginRepository : ILoginRepository
    {
        UserAcessEntities _userAcessEntities;

        public LoginRepository(UserAcessEntities userAcessEntities)
        {
            _userAcessEntities = userAcessEntities;
        }

        public UserViewModel GetUserbyLoginName(string loginName, string password)
        {
            using (_userAcessEntities)
            {
                return _userAcessEntities.Users.Where(x => x.LoginName == loginName && x.Password == password)
                    .Select(x => new UserViewModel
                    {
                        UserId = x.UserId,
                        UserName = x.UserName,
                        UserType = x.UserType
                    })
                    .FirstOrDefault();
            }
        }
    }
}
