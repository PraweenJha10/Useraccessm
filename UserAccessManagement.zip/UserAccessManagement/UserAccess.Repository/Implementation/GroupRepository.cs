﻿using System;
using System.Collections.Generic;
using System.Linq;
using UserAccess.Repository.Interfaces;
using UserAccess.Repository.Models;
using UserAccess.ViewModel;

namespace UserAccess.Repository.Implementation
{
    public class GroupRepository : IGroupRepository
    {
        private UserAcessEntities _userAcessEntities;

        public GroupRepository(UserAcessEntities userAcessEntities)
        {
            _userAcessEntities = userAcessEntities;
        }

        public int AddGroup(GroupViewModel group)
        {
            group.CreatedDate = DateTime.Now;
            group.ModifiedDate = DateTime.Now;
            Group createdGroup = null;
            using (_userAcessEntities)
            {
                createdGroup = _userAcessEntities.Groups.Add(new Group { GroupId = group.GroupId, GroupName = group.GroupName, CreatedDate = group.CreatedDate, ModifiedDate=group.ModifiedDate });
                _userAcessEntities.SaveChanges();
            }
            return createdGroup.GroupId;
        }

        public GroupViewModel GetGroupbyId(int GroupId)
        {
            GroupViewModel group;
            using (_userAcessEntities)
            {
                group = _userAcessEntities.Groups.Where(g => g.GroupId == GroupId).Select(g => new GroupViewModel
                {
                    GroupId = g.GroupId,
                    GroupName = g.GroupName,
                    CreatedDate = g.CreatedDate,
                    ModifiedDate = g.ModifiedDate
                }).FirstOrDefault();
            }
            return group;
        }

        public IEnumerable<GroupViewModel> GetGroups()
        {
            IEnumerable<GroupViewModel> groups = null;
            using (_userAcessEntities)
            {
                groups =  _userAcessEntities.Groups.Select(g => new GroupViewModel
                {
                    GroupId = g.GroupId,
                    GroupName = g.GroupName,
                    CreatedDate = g.CreatedDate,
                    ModifiedDate = g.ModifiedDate
                }).ToList();
            }
            return groups;
        }

        public bool IsGroupExist(string GroupName)
        {
            using (_userAcessEntities)
            {
                return _userAcessEntities.Groups.Any(g => g.GroupName == GroupName);
            }
        }
    }
}
