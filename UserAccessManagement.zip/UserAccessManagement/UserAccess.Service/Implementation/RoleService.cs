﻿using System.Collections.Generic;
using UserAccess.Repository.Interfaces;
using UserAccess.Service.Interfaces;
using UserAccess.ViewModel;



namespace UserAccess.Service.Implementation
{
    public class RoleService : IRoleService
    {
        IRoleRepository _RoleRepository;

        public RoleService(IRoleRepository RoleRepository)
        {
            _RoleRepository = RoleRepository;
        }

        public int AddRole(RoleViewModel Role)
        {
            return _RoleRepository.AddRole(Role);
        }

        public RoleViewModel GetRolebyId(int RoleId)
        {
            return _RoleRepository.GetRolebyId(RoleId);
        }

        public IEnumerable<RoleViewModel> GetRoles()
        {
            return _RoleRepository.GetRoles();
        }

        public bool IsRoleExist(string RoleName)
        {
            return _RoleRepository.IsRoleExist(RoleName);
        }
    }
}
