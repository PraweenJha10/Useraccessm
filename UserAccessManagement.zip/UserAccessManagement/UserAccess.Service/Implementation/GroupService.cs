﻿using System.Collections.Generic;
using UserAccess.Repository.Interfaces;
using UserAccess.Service.Interfaces;
using UserAccess.ViewModel;



namespace UserAccess.Service.Implementation
{
    public class GroupService : IGroupService
    {
        IGroupRepository _groupRepository;

        public GroupService(IGroupRepository groupRepository)
        {
            _groupRepository = groupRepository;
        }

        public int AddGroup(GroupViewModel group)
        {
            return _groupRepository.AddGroup(group);
        }

        public GroupViewModel GetGroupbyId(int GroupId)
        {
            return _groupRepository.GetGroupbyId(GroupId);
        }

        public IEnumerable<GroupViewModel> GetGroups()
        {
            return _groupRepository.GetGroups();
        }

        public bool IsGroupExist(string GroupName)
        {
            return _groupRepository.IsGroupExist(GroupName);
        }
    }
}
