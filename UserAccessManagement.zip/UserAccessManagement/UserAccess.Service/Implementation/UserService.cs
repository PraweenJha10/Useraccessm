﻿using System.Collections.Generic;
using UserAccess.Repository.Interfaces;
using UserAccess.Service.Interfaces;
using UserAccess.ViewModel;



namespace UserAccess.Service.Implementation
{
    public class UserService : IUserService
    {
        IUserRepository _UserRepository;

        public UserService(IUserRepository UserRepository)
        {
            _UserRepository = UserRepository;
        }

        public int AddUser(UserViewModel User)
        {
            return _UserRepository.AddUser(User);
        }

        public UserViewModel GetUserbyId(int UserId)
        {
            return _UserRepository.GetUserbyId(UserId);
        }

        public IEnumerable<UserViewModel> GetUsers()
        {
            return _UserRepository.GetUsers();
        }

        public bool IsUserExist(string UserName)
        {
            return _UserRepository.IsUserExist(UserName);
        }
    }
}
