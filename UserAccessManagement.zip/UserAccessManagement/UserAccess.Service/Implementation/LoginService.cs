﻿using UserAccess.Repository.Interfaces;
using UserAccess.Service.Interfaces;
using UserAccess.ViewModel;



namespace UserAccess.Service.Implementation
{
    public class LoginService : ILoginService
    {
        ILoginRepository _loginRepository;

        public LoginService(ILoginRepository loginRepository)
        {
            _loginRepository = loginRepository;
        }

        public UserViewModel GetUserbyLoginName(string loginName, string password)
        {
            return _loginRepository.GetUserbyLoginName(loginName, password);
        }
    }
}
