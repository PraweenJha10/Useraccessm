﻿using System.Collections.Generic;
using UserAccess.Repository.Interfaces;
using UserAccess.Service.Interfaces;
using UserAccess.ViewModel;



namespace UserAccess.Service.Implementation
{
    public class UserRoleGroupMapService : IUserRoleGroupMapService
    {
        IUserRoleGroupMapRepository _userRoleGroupMapRepository;

        public UserRoleGroupMapService(IUserRoleGroupMapRepository userRoleGroupMapRepository)
        {
            _userRoleGroupMapRepository = userRoleGroupMapRepository;
        }

        public int AddUpdateUserRoleGroupMapping(IEnumerable<UserRoleGroupNameViewModel> userRoleGroupViewModel)
        {
            return _userRoleGroupMapRepository.AddUpdateUserRoleGroupMapping(userRoleGroupViewModel);
        }

        public UserRoleGroupAssign GetUserRoleGroupAssignByUserId(int userId)
        {
            return _userRoleGroupMapRepository.GetUserRoleGroupAssignByUserId(userId);
        }

        public IEnumerable<UserRoleGroupNameViewModel> GetuserRoleGroupNamebyUseridRoleId(int UserId, int RoleId)
        {
            return _userRoleGroupMapRepository.GetuserRoleGroupNamebyUseridRoleId(UserId, RoleId);
        }

        public IEnumerable<UserRoleViewModel> GetUserRoles()
        {
            return _userRoleGroupMapRepository.GetUserRoles();
        }
    }
}
