﻿using System.Collections.Generic;
using UserAccess.Repository.Interfaces;
using UserAccess.Service.Interfaces;
using UserAccess.ViewModel;



namespace UserAccess.Service.Implementation
{
    public class RoleGroupMappingService : IRoleGroupMappingService
    {
        IRoleGroupMapRepository _roleGroupMapRepository;

        public RoleGroupMappingService(IRoleGroupMapRepository roleGroupMapRepository)
        {
            _roleGroupMapRepository = roleGroupMapRepository;
        }

        public int AddupdateRoleGroup(IEnumerable<RoleGroupViewModel> roleGroup)
        {
            return _roleGroupMapRepository.AddupdateRoleGroup(roleGroup);
        }

        public IEnumerable<RoleGroupNameViewModel> GetRoleGroupByRoleId(int RoleId)
        {
            return _roleGroupMapRepository.GetRoleGroupByRoleId(RoleId);
        }

        public IEnumerable<RoleGroupNameViewModel> GetRoleGroupNameByRoleId(int RoleId)
        {
            return _roleGroupMapRepository.GetRoleGroupNameByRoleId(RoleId);
        }

        public int GetUserbyRoleidGroupid(int RoleId, int GroupId)
        {
            return _roleGroupMapRepository.GetUserbyRoleidGroupid(RoleId, GroupId);
        }
    }
}
