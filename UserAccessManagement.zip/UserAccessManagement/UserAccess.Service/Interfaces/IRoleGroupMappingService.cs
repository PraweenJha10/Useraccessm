﻿using System.Collections.Generic;
using UserAccess.ViewModel;

namespace UserAccess.Service.Interfaces
{
    public interface IRoleGroupMappingService
    {
        int AddupdateRoleGroup(IEnumerable<RoleGroupViewModel> roleGroup);
        int GetUserbyRoleidGroupid(int RoleId, int GroupId);
        IEnumerable<RoleGroupNameViewModel> GetRoleGroupByRoleId(int RoleId);
        IEnumerable<RoleGroupNameViewModel> GetRoleGroupNameByRoleId(int RoleId);
    }
}
