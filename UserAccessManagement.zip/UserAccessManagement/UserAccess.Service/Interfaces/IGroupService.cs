﻿using System.Collections.Generic;
using UserAccess.ViewModel;

namespace UserAccess.Service.Interfaces
{
    public interface IGroupService
    {
        int AddGroup(GroupViewModel group);
        bool IsGroupExist(string GroupName);
        IEnumerable<GroupViewModel> GetGroups();
        GroupViewModel GetGroupbyId(int GroupId);
    }
}
