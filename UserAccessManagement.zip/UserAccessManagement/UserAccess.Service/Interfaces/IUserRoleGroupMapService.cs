﻿using System.Collections.Generic;
using UserAccess.ViewModel;

namespace UserAccess.Service.Interfaces
{
    public interface IUserRoleGroupMapService
    {
        IEnumerable<UserRoleViewModel> GetUserRoles();
        int AddUpdateUserRoleGroupMapping(IEnumerable<UserRoleGroupNameViewModel> userRoleGroupViewModel);
        IEnumerable<UserRoleGroupNameViewModel> GetuserRoleGroupNamebyUseridRoleId(int UserId, int RoleId);
        UserRoleGroupAssign GetUserRoleGroupAssignByUserId(int userId);
    }
}
