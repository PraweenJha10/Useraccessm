﻿using System.Collections.Generic;
using UserAccess.ViewModel;

namespace UserAccess.Service.Interfaces
{
    public interface IRoleService
    {
        int AddRole(RoleViewModel Role);
        bool IsRoleExist(string RoleName);
        IEnumerable<RoleViewModel> GetRoles();
        RoleViewModel GetRolebyId(int RoleId);
    }
}
