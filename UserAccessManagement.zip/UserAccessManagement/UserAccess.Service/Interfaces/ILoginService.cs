﻿using UserAccess.ViewModel;

namespace UserAccess.Service.Interfaces
{
    public interface ILoginService
    {
        UserViewModel GetUserbyLoginName(string loginName, string password);
    }
}
