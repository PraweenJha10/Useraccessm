﻿using System.Collections.Generic;
using UserAccess.ViewModel;

namespace UserAccess.Service.Interfaces
{
    public interface IUserService
    {
        int AddUser(UserViewModel User);
        bool IsUserExist(string UserName);
        IEnumerable<UserViewModel> GetUsers();
        UserViewModel GetUserbyId(int UserId);
    }
}
