﻿using System;
using System.Collections.Generic;
using System.Web.Http;
using UserAccess.Service.Interfaces;
using UserAccess.ViewModel;

namespace UserAccessManagement.Controllers
{
    [RoutePrefix("api/rolegroupmap")]
    public class RoleGroupMappingController : ApiController
    {
        IRoleGroupMappingService _roleGroupMappingService;

        public RoleGroupMappingController(IRoleGroupMappingService roleGroupMappingService)
        {
            _roleGroupMappingService = roleGroupMappingService;
        }


        #region : Method to get role by groupid

        [HttpGet]
        [Route("getrolegroupbyid")]
        public IHttpActionResult GetRoleGroupByRoleId(int RoleId)
        {
            try
            {
                if (RoleId > 0)
                {
                    return Ok(_roleGroupMappingService.GetRoleGroupByRoleId(RoleId));
                }
                else
                {
                    return BadRequest("Invalide RoleId");
                }
            }
            catch (Exception ex)
            {
                return BadRequest("Error : " + ex.Message);
            }            
        }
        #endregion

        #region : Method to get group name by id
        [HttpGet]
        [Route("getrolegroupnamebyid")]
        public IHttpActionResult GetRoleGroupNameByRoleId(int RoleId)
        {
            try
            {
                if (RoleId > 0)
                {
                    return Ok(_roleGroupMappingService.GetRoleGroupNameByRoleId(RoleId));
                }
                else
                {
                    return BadRequest("Invalide RoleId");
                }
            }
            catch (Exception ex)
            {
                return BadRequest("Error : " + ex.Message);
            }
        }
        #endregion

        #region : Method to get user by role and group
        [HttpGet]
        [Route("getUserbyRoleidGroupid")]
        public IHttpActionResult GetUserbyRoleidGroupid(int RoleId, int GroupId)
        {
            try
            {
                if (RoleId > 0 && GroupId > 0)
                {
                    return Ok(_roleGroupMappingService.GetUserbyRoleidGroupid(RoleId, GroupId));
                }
                else
                {
                    return BadRequest("Invalide RoleId/GroupId");
                }
            }
            catch (Exception ex)
            {
                return BadRequest("Error : " + ex.Message);
            }

        }
        #endregion

        #region : Method to update role group
        [HttpPost]
        [Route("addupdaterolegroup")]
        public IHttpActionResult AddupdateRoleGroup(IEnumerable<RoleGroupViewModel> roleGroup)
        {
            try
            {
                return Ok(_roleGroupMappingService.AddupdateRoleGroup(roleGroup));
            }
            catch (Exception ex)
            {
                return BadRequest("Error : " + ex.Message);
            }
            
        }
        #endregion
    }
}
