﻿using System;
using System.Web.Http;
using UserAccess.Service.Interfaces;

namespace UserAccessManagement.Controllers
{
    [RoutePrefix("api/login")]
    public class LoginController : ApiController
    {
        ILoginService _loginService;

        public LoginController(ILoginService loginService)
        {
            _loginService = loginService;
        }

        #region : Method to get user details by login name
        [HttpGet]
        [Route("getUserbyLoginName")]
        public IHttpActionResult GetUserbyLoginName(string loginName, string password)
        {
            try
            {
                if (string.IsNullOrEmpty(loginName) || string.IsNullOrEmpty(password))
                {
                    return BadRequest("Invalid Loginname and or password");
                }
                else
                {
                    var logindetails = _loginService.GetUserbyLoginName(loginName, password);
                    if (logindetails != null)
                    {
                        return Ok(logindetails);
                    }

                    else
                    {
                        return BadRequest("Invalid Loginname and or password");
                    }

                }
            }
            catch (Exception ex)
            {

                return BadRequest("Error : " + ex.Message);
            }
        }
        #endregion
    }
}
