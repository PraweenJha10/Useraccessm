﻿using System;
using System.Collections.Generic;
using System.Web.Http;
using UserAccess.Service.Interfaces;
using UserAccess.ViewModel;

namespace UserAccessManagement.Controllers
{
    [RoutePrefix("api/userrolegroupmap")]
    public class UserRoleGroupMappingController : ApiController
    {
        IUserRoleGroupMapService _userRoleGroupMapService;

        public UserRoleGroupMappingController(IUserRoleGroupMapService userRoleGroupMapService)
        {
            _userRoleGroupMapService = userRoleGroupMapService;
        }
        #region : Method to get user roles
        [HttpGet]
        [Route("getUserRoles")]
        public IHttpActionResult GetUserRoles()
        {
            try
            {                
                    return Ok(_userRoleGroupMapService.GetUserRoles());                
            }
            catch (Exception ex)
            {
                return BadRequest("Error : " + ex.Message);
            }            
        }
        #endregion

        #region : Method to add user role group
        [Route("addUpdateUserRoleGroupMap")]
        [HttpPost]
        public IHttpActionResult AddUpdateUserRoleGroupMapping(IEnumerable<UserRoleGroupNameViewModel> userRoleGroupViewModel)
        {
            try
            {
                return Ok(_userRoleGroupMapService.AddUpdateUserRoleGroupMapping(userRoleGroupViewModel));
            }
            catch (Exception ex)
            {
                return BadRequest("Error : " + ex.Message);
            }
        }
        #endregion

        #region : Method to get user role group by user id role id
        [HttpGet]
        [Route("getuserrolegroupNamebyuseridroleId")]
        public IHttpActionResult GetuserRoleGroupNamebyUseridRoleId(int UserId, int RoleId)
        {
            try
            {
                if(UserId >0 && RoleId > 0)
                {
                    return Ok(_userRoleGroupMapService.GetuserRoleGroupNamebyUseridRoleId(UserId, RoleId));
                }
                else
                {
                    return BadRequest("Invalid Userid or RoleId");
                }
            }
            catch (Exception ex)
            {
                return BadRequest("Error : " + ex.Message);
            }
        }
        #endregion

        #region : Method to get user role group by userid
        [HttpGet]
        [Route("getuserrolegroupassignbyuserId")]
        public IHttpActionResult GetUserRoleGroupAssignByUserId(int userId)


        {
            try
            {
                return Ok(_userRoleGroupMapService.GetUserRoleGroupAssignByUserId(userId));
            }
            catch (Exception ex)
            {

                return BadRequest("Error: " + ex.Message);
            }
        }
        #endregion
    }
}
