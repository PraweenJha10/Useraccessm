﻿using System;
using System.Web.Http;
using UserAccess.Service.Interfaces;
using UserAccess.ViewModel;

namespace UserAccessManagement.Controllers
{
    [RoutePrefix("api/User")]
    public class UserController : ApiController
    {
        IUserService _UserService;

        public UserController(IUserService UserService)
        {
            _UserService = UserService;
        }

        #region : Method to add user
        [HttpPost]
        [Route("addUser")]
        public IHttpActionResult AddUser(UserViewModel User)
        {
            try {
                return Ok(_UserService.AddUser(User));
            }
            catch(Exception ex)
            {
                return BadRequest("Could not add user : " + ex.Message);
            }
        }
        #endregion

        #region : Method to get user by id
        [HttpGet]
        [Route("getUserbyid")]
        public IHttpActionResult GetUserbyId(int id)
        {
            try { 
                if(id > 0) { 
                    return Ok(_UserService.GetUserbyId(id));
                }
                else
                {
                    return BadRequest("Invalid Id");
                }
            }
            catch(Exception ex)
            {
                return BadRequest("Could not fetch user : " + ex.Message);
            }
        }
        #endregion

        #region : Method to get users
        [HttpGet]
        [Route("getUsers")]
        public IHttpActionResult GetUsers()
        {
            try
            {
                return Ok(_UserService.GetUsers());
            }
            catch(Exception ex)
            {
                return BadRequest("Could not fetch user : " + ex.Message);
            }
        }
        #endregion

        #region : Method to check login exists
        [HttpGet]
        [Route("isloginexist")]
        public IHttpActionResult IsUserExist(string LoginName)
        {
            try {
                if (LoginName != "") { 
                    return Ok(_UserService.IsUserExist(LoginName));
                }
                else
                {
                    return BadRequest("Not a valid LoginName");
                }
            }
            catch(Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        #endregion
    }
}
