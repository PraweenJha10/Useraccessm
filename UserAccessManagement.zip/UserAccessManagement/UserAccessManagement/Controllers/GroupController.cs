﻿using System;
using System.Web.Http;
using UserAccess.Service.Interfaces;
using UserAccess.ViewModel;

namespace UserAccessManagement.Controllers
{
    [RoutePrefix("api/group")]
    public class GroupController : ApiController
    {
        IGroupService _groupService;


        public GroupController(IGroupService groupService)
        {
            _groupService = groupService;
        }


        #region : Method for adding group
        [HttpPost]
        [Route("addgroup")]
        public IHttpActionResult AddGroup(GroupViewModel group)
        {
            try
            {
                return Ok(_groupService.AddGroup(group));
            }
            catch (Exception ex)
            {

                return BadRequest("Error : Bad request: Something went wrong");
            }

        }
        #endregion

        #region : Method to get group by ID
        [HttpGet]
        [Route("getgroupbyid")]
        public IHttpActionResult GetGroupbyId(int id)
        {
            try
            {
                if (id > 0)
                {
                    return Ok(_groupService.GetGroupbyId(id));
                }
                else
                {
                    return BadRequest("Invalid Id");
                }
            }
            catch (Exception ex)
            {
                return BadRequest("Error : Bad request: Something went wrong");
            }
        }
        #endregion

        #region : Method to get groups
        [HttpGet]
        [Route("getgroups")]
        public IHttpActionResult GetGroups()
        {
            try
            {
                return Ok(_groupService.GetGroups());
            }
            catch (Exception ex)
            {

                return BadRequest("Error : Bad request: Something went wrong");
            }
        }
        #endregion

        #region: Method to check group exist or not
        [HttpGet]
        [Route("isgroupexist")]
        public IHttpActionResult IsGroupExist(string GroupName)
        {
            try
            {
                return Ok(_groupService.IsGroupExist(GroupName));
            }
            catch (Exception ex)
            {
                return BadRequest("Error : Bad request: Something went wrong");
            }
        }
        #endregion
    }
}
