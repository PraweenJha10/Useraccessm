﻿using System;
using System.Web.Http;
using UserAccess.Service.Interfaces;
using UserAccess.ViewModel;

namespace UserAccessManagement.Controllers
{
    [RoutePrefix("api/Role")]
    public class RoleController : ApiController
    {

        IRoleService _RoleService;


        public RoleController(IRoleService RoleService)
        {
            _RoleService = RoleService;
        }

        #region : Method to add Role
        [HttpPost]
        [Route("addRole")]
        public IHttpActionResult AddRole(RoleViewModel Role)
        {
            try {
                return Ok(_RoleService.AddRole(Role));
            }
            catch(Exception ex)
            {
                return BadRequest("Could Not add Role : "+ ex.Message);
            }

        }
        #endregion

        #region : Method to get role by id
        [HttpGet]
        [Route("getRolebyid")]
        public IHttpActionResult GetRolebyId(int id)
        {
            try
            {
                if (id > 0)
                {
                    return Ok(_RoleService.GetRolebyId(id));
                }
                else
                {
                    return BadRequest("Invalid Id");
                }
            }
            catch (Exception ex)
            {
                return BadRequest("Error : " + ex.Message);
            }
            
        }
        #endregion

        #region : Method to get roles
        [HttpGet]
        [Route("getRoles")]
        public IHttpActionResult GetRoles()
        {
            try
            {                
                return Ok(_RoleService.GetRoles());
            }
            catch (Exception ex)
            {
                return BadRequest("Error : " + ex.Message);
            }
            
        }

        #endregion

        #region : Method to check role exists
        [HttpGet]
        [Route("isRoleexist")]
        public IHttpActionResult IsRoleExist(string RoleName)
        {
            try
            {
                if (!string.IsNullOrEmpty(RoleName)) { 
                return Ok(_RoleService.IsRoleExist(RoleName));
                }
                else
                {
                    return BadRequest("Invalid RoleName");
                }
            }
            catch (Exception ex)
            {
                return BadRequest("Error : " + ex.Message);
            }
            
        }
        #endregion
    }
}
