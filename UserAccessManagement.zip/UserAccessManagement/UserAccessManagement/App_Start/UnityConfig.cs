using System.Web.Http;
using Unity;
using Unity.WebApi;
using UserAccess.Repository.Implementation;
using UserAccess.Repository.Interfaces;
using UserAccess.Repository.Models;
using UserAccess.Service.Implementation;
using UserAccess.Service.Interfaces;

namespace UserAccessManagement
{
    public static class UnityConfig
    {
        public static void RegisterComponents()
        {
			var container = new UnityContainer();

            // register all your components with the container here
            // it is NOT necessary to register your controllers

            // e.g. container.RegisterType<ITestService, TestService>();


            container.RegisterType<UserAcessEntities, UserAcessEntities>();

            container.RegisterType<IGroupRepository, GroupRepository>();
            container.RegisterType<IGroupService, GroupService>();
            container.RegisterType<IRoleRepository, RoleRepository>();
            container.RegisterType<IRoleService, RoleService>();
            container.RegisterType<IUserRepository, UserRepository>();
            container.RegisterType<IUserService, UserService>();
            container.RegisterType<IRoleGroupMapRepository, RoleGroupMapRepository>();
            container.RegisterType<IRoleGroupMappingService, RoleGroupMappingService>();
            container.RegisterType<IUserRoleGroupMapRepository, UserRoleGroupMapRepository>();
            container.RegisterType<IUserRoleGroupMapService, UserRoleGroupMapService>();
            container.RegisterType<ILoginRepository, LoginRepository>();
            container.RegisterType<ILoginService, LoginService>();


            GlobalConfiguration.Configuration.DependencyResolver = new UnityDependencyResolver(container);
        }
    }
}