﻿namespace UserAccess.ViewModel
{
    public class UserRoleViewModel
    {
        public int UserId { get; set; }
        public string UserName { get; set; }
        public int? RoleId { get; set; }
        public string RoleName { get; set; }
        public string LoginName { get; set; }
        public string UserType { get; set; }
    }
}
