﻿namespace UserAccess.ViewModel
{
    public class RoleGroupNameViewModel
    {
        public int GroupId { get; set; }
        public string GroupName { get; set; }
        public bool IsActive { get; set; }
    }
}
