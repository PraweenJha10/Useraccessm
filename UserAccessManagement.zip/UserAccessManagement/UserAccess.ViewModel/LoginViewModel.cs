﻿namespace UserAccess.ViewModel
{
    public class LoginViewModel
    {
        public int LoginId { get; set; }
        public string LoginName { get; set; }
        public string Password { get; set; }
        public string UserType { get; set; }
    }
}
