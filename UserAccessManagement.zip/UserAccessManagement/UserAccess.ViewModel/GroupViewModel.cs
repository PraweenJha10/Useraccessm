﻿using System;
using System.ComponentModel.DataAnnotations;

namespace UserAccess.ViewModel
{
    public class GroupViewModel
    {
        [Required]
        public int GroupId { get; set; }
        [Required]
        public string GroupName { get; set; }
        public DateTime CreatedDate { get; set; }
        public DateTime ModifiedDate { get; set; }
        public bool? IsActive { get; set; }
    }
}
