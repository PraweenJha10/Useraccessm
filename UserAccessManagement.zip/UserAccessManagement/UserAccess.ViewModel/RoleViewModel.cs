﻿using System;
using System.ComponentModel.DataAnnotations;

namespace UserAccess.ViewModel
{
    public class RoleViewModel
    {
        public int RoleId { get; set; }
        [Required]
        public string RoleName { get; set; }
        public Nullable<System.DateTime> CreatedDate { get; set; }
        public Nullable<System.DateTime> ModifiedDate { get; set; }
    }
}
