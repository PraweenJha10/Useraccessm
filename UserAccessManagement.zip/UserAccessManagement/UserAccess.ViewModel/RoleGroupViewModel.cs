﻿using System.ComponentModel.DataAnnotations;

namespace UserAccess.ViewModel
{
    public class RoleGroupViewModel
    {
        public int RoleGroupId { get; set; }
        [Required]
        public int RoleId { get; set; }
        [Required]
        public int GroupId { get; set; }
        public bool IsActive { get; set; }
    }
}
