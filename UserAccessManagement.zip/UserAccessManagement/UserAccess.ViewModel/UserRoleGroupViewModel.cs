﻿using System.ComponentModel.DataAnnotations;

namespace UserAccess.ViewModel
{
    public class UserRoleGroupViewModel
    {
        public int UserRoleGroupId { get; set; }
        [Required]
        public int UserId { get; set; }
        public int RoleId { get; set; }
        public int GroupId { get; set; }
        public bool IsActive { get; set; }
    }
}
