﻿using System.Collections.Generic;

namespace UserAccess.ViewModel
{
    public class UserRoleGroupAssign
    {
        public int UserId { get; set; }
        public int RoleId { get; set; }
        public string RoleName { get; set; }
        public List<GroupViewModel> Groups { get; set; }
    }
}
