﻿using System;
using System.ComponentModel.DataAnnotations;

namespace UserAccess.ViewModel
{
    public class UserViewModel
    {
        public int UserId { get; set; }
        [Required]
        public string UserName { get; set; }
        public Nullable<System.DateTime> CreatedDate { get; set; }
        public Nullable<System.DateTime> ModifiedDate { get; set; }
        [Required]
        public string LoginName { get; set; }
        [Required]
        public string Password { get; set; }
        [Required]
        public string UserType { get; set; }
    }
}
