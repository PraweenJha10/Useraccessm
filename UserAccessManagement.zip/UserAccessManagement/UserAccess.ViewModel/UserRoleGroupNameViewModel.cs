﻿namespace UserAccess.ViewModel
{
    public class UserRoleGroupNameViewModel
    {
        public int UserRoleGroupId { get; set; }
        public int UserId { get; set; }
        public int RoleId { get; set; }
        public string UserName { get; set; }
        public string RoleName { get; set; }
        public int GroupId { get; set; }
        public string GroupName { get; set; }
        public bool? IsActive { get; set; }
    }
}
