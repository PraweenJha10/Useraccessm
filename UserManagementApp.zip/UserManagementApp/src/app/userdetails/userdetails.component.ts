import { Component, OnInit, ViewChild, Output, EventEmitter } from '@angular/core';
import { MatSort, MatPaginator, MatTableDataSource } from '@angular/material';


import { UserService } from '../shared/services/user.service';
import { User } from '../shared/models/user.model';
import { UserRoleGroupNameService } from '../shared/services/user-role-group-name.service';
@Component({
  selector: 'app-userdetails',
  templateUrl: './userdetails.component.html',
  styleUrls: ['./userdetails.component.css']
})
export class UserdetailsComponent implements OnInit {
  title = 'app';
  displayedColumns = [ 'UserId', 'UserName', 'LoginName', 'RoleName', 'UserType', 'actions'];
  @Output('useredit') useredit = new EventEmitter<User>();

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  constructor(private userRoleGroupNameService: UserRoleGroupNameService, private userService: UserService) { }
  data: User[];
  dataSource: MatTableDataSource<User>;

  ngOnInit() {
    this.userService.getUserList().pipe().subscribe(data => {
      this.data = data;
    },
      (e)=>{},
      () => {
        this.dataSource = new MatTableDataSource(this.data);
        this.dataSource.sort = this.sort;
        this.dataSource.paginator = this.paginator;
      });

  }

  applyFilter(filterValue: string) {
    filterValue = filterValue.trim(); // Remove whitespace
    filterValue = filterValue.toLowerCase(); // MatTableDataSource defaults to lowercase matches
    this.dataSource.filter = filterValue;
    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }
  OnEditUser(element: User) {
    this.userRoleGroupNameService.getUserRoleDetails(element.UserId)
      .subscribe(x => {
        this.userService.selectedUser = x;
        this.userService.UserName = element.UserName;
        this.userService.selectedUser.UserId = element.UserId;
      });
  }
}


