import { environment } from "../../../environments/environment";


export const BaseUrl: string = environment.BaseUrl;