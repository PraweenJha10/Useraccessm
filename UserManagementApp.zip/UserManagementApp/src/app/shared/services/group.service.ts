import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Group } from '../models/group.model';
import { Observable } from 'rxjs';
//import { BaseUrl } from './config';
import { LoginService } from './login.service';


@Injectable({
  providedIn: 'root'
})
export class GroupService {
  BaseUrl :string;

  constructor(private http: HttpClient,private loginService:LoginService) { 
    this.BaseUrl = this.loginService.APIUrl;
  }

  /* Service to get full Group list*/
  getGroupList() {
    return this.http.get<Group[]>(this.BaseUrl + "group/getgroups");
  }

  /* Service call to check if group name is already exist*/
  IsGroupExists(groupName: string) {
    return this.http.get<boolean>(this.BaseUrl + "group/isgroupexist?GroupName=" + groupName);
  }
  /* Service call to save new Group*/
  
  postGroup(group: Group): Observable<Group> {
    return this.http.post<Group>(this.BaseUrl + "group/addgroup", group, {
      headers: new HttpHeaders({
        'Accept': 'application/json'
      })
    });
  }

}
