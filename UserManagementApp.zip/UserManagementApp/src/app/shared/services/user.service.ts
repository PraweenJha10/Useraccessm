import { Injectable } from '@angular/core';
import { Http, Response, Headers, RequestOptions, RequestMethod } from '@angular/http';
import { Observable } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { User } from '../models/user.model';
//import { BaseUrl } from './config';
import { UserRoleGroupAssign } from '../models/UserRoleGroupAssign.model';
import { LoginService } from './login.service';


@Injectable()
export class UserService {
    selectedUser: UserRoleGroupAssign;
    UserName: string;
    BaseUrl : string;


    constructor(private http: HttpClient,private loginService:LoginService) {
        this.BaseUrl = this.loginService.APIUrl;
     }
/* Service call to get User list*/  
    getUserList() {
        return this.http.get<User[]>(this.BaseUrl + "userrolegroupmap/getUserRoles");
    }
/* Service call to check if the user already exist*/  
    isUserExist(name: string) {
        return this.http.get<User[]>(this.BaseUrl + "User/isloginexist?LoginName=" + name);
    }
    /* Service call to add new user*/  
    AddUser(user: User) {
        return this.http.post<User>(this.BaseUrl + "User/addUser", user, {
            headers: new HttpHeaders({
                'Accept': 'application/json'
            })
        });
    }

}