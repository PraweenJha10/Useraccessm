import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Role } from '../models/role.model';
import { Group } from '../models/group.model';
import { Observable } from 'rxjs';
//import { BaseUrl } from './config';
import { LoginService } from './login.service';

@Injectable({
  providedIn: 'root'
})
export class RoleService {
  BaseUrl:string;
  constructor(private http: HttpClient,private loginService:LoginService) {
    this.BaseUrl = this.loginService.APIUrl;
   }
  /* Service call to get Role list */  
  getRoleList() {
    return this.http.get<Role[]>(this.BaseUrl + "Role/getRoles");
  }
  /* Service call to check if role name is exist*/  
  IsRoleExists(rolename: string) {
    return this.http.get<boolean>(this.BaseUrl + "Role/isRoleexist?RoleName=" + rolename);
  }
  /* Service call to save a new Role */  
  postRole(role: Role): Observable<Role> {
    return this.http.post<Role>(this.BaseUrl + "Role/addRole", role, {
      headers: new HttpHeaders({
        'Accept': 'application/json'
      })
    });
  }

}
