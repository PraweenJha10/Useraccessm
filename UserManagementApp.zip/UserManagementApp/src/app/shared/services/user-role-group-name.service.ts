import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Role } from '../models/role.model';
import { Observable } from 'rxjs';
import { Group } from '../models/group.model';
import { UserRoleGroupName } from '../models/user-role-group-name.model';
import { UserRoleGroupAssign } from '../models/UserRoleGroupAssign.model';
import { BaseUrl } from './config';
import { LoginService } from './login.service';

@Injectable({
  providedIn: 'root'
})
export class UserRoleGroupNameService {
  BaseUrl:string;
  constructor(private http: HttpClient,private loginService:LoginService) {
    this.BaseUrl = this.loginService.APIUrl;
   }
/* Service call to add and update user role group */  
  addUpdateUserRoleGroupMapping(userRoleGroupName: UserRoleGroupName[]) {
    return this.http.post<UserRoleGroupName[]>(this.BaseUrl + "userrolegroupmap/addUpdateUserRoleGroupMap", userRoleGroupName, {
      headers: new HttpHeaders({
        'Accept': 'application/json'
      })
    });
  }
  /* Service call to get user's role details */  
  getUserRoleDetails(userid: number) {

    return this.http.get<UserRoleGroupAssign>(this.BaseUrl + "userrolegroupmap/getuserrolegroupassignbyuserId?userId=" + userid);
  }
/* Service call to get User Role Group based on userid and Role Id */  
  GetuserRoleGroupNamebyUseridRoleId(userid: number, roleid: number) {
    return this.http.get<UserRoleGroupName>(this.BaseUrl + "userrolegroupmap/getuserrolegroupNamebyuseridroleId?UserId=" + userid + "&RoleId=" + roleid);
  }



}
