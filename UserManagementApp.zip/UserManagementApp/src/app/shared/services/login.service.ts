import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, BehaviorSubject } from 'rxjs';
import { User } from '../models/user.model';
import { BaseUrl } from './config';

@Injectable({
  providedIn: 'root'
})
export class LoginService {
  private source = new BehaviorSubject<string>('');
  APIUrl :string;
  cururl:any;
  constructor(private http: HttpClient) { 
    this.http.get("../../../assets/urlConfig.json").subscribe(data => { 
      this.cururl = data;
      this.APIUrl = this.cururl.api;
    });
  }
  /* Service call to validate user login*/  
  getUserbyLoginName(userName: string, password: string) {
    return this.http.get<User>(BaseUrl + "Login/getUserbyLoginName?loginName=" + userName + "&password=" + password);
  }
}