import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Role } from '../models/role.model';
import { Observable } from 'rxjs';
import { Group } from '../models/group.model';
import { RoleGroup } from '../models/RoleGroup.model';
import { UserGroup } from '../models/user-role-group-name.model';
//import { BaseUrl } from './config';
import { LoginService } from './login.service';

@Injectable({
  providedIn: 'root'
})
export class RoleGroupService {
  BaseUrl:string;
  roleGroup: RoleGroup;
  constructor(private http: HttpClient,private loginService:LoginService) { 
    this.BaseUrl = this.loginService.APIUrl;
  }
/* Service call to get full role list*/  
  getRoleList() {
    return this.http.get<Role[]>(this.BaseUrl + "role/getRoles");
  }
/* Service call to get Group associated with the role*/  
  getGroupListByRole(roleId: number) {
    return this.http.get<Group[]>(this.BaseUrl + "rolegroupmap/getrolegroupbyid?RoleId=" + roleId);
  }

  /* Service call to get Group name by role id*/  
  getGroupNameByRole(roleId: number) {
    return this.http.get<UserGroup[]>(this.BaseUrl + "rolegroupmap/getrolegroupnamebyid?RoleId=" + roleId);
  }
/* Service call to save role-group mapping data*/  
  updateRoleGroups(roleGroup: RoleGroup[]) {
    return this.http.post<RoleGroup[]>(this.BaseUrl + "rolegroupmap/addupdaterolegroup", roleGroup, {
      headers: new HttpHeaders({
        'Accept': 'application/json'
      })
    });
  }
}
