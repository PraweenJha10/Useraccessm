
export class RoleGroup {
    RoleGroupId: number;
    RoleId: number;
    GroupId: number;
    IsActive: boolean;
}
