
export class User {
    UserId : number;
    UserName: string;
    LoginName: string;
    RoleId: number;
    RoleName: string;
    UserType: string;
} 
