export class Group {
    GroupId: number;
    GroupName: string;
}