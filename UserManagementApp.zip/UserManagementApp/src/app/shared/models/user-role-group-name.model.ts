
export  class  UserRoleGroupName  {
    UserRoleGroupId:  number;
    UserId: number;
    RoleId: number;
    UserName: string;
    RoleName: string
    GroupId: number;
    GroupName: string
    IsActive: boolean;
}

export class UserGroup {
    GroupId: number;
    GroupName: string;
    IsActive: boolean;
}
