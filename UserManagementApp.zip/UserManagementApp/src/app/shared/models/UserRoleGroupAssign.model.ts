
import { UserGroup } from "./user-role-group-name.model";

export class UserRoleGroupAssign {
    UserId: number;
    RoleId: number;
    RoleName: string;
    Groups: UserGroup[];
}