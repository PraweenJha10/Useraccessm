export class Role {
    RoleId: number;
    RoleName: string;
}
export class AllRole {
    RoleId: number;
    RoleName: string;
    isActibve: boolean
}