
export  class  RoleGroupName {
    GroupId:  number;
    GroupName: string;
    IsActive: boolean;
}
