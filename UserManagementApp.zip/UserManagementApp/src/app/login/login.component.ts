import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../auth.service';
import { LoginService } from '../shared/services/login.service';
import { User } from '../shared/models/user.model';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  loginForm;
  user: User;
  constructor(private toastr: ToastrService, private fb: FormBuilder, private myRoute: Router,
    private auth: AuthService, private loginService: LoginService) {
    this.loginForm = fb.group({
      username: ['', Validators.required],
      password: ['', Validators.required]

    });
  }

  ngOnInit() {
    history.pushState(null, null, location.href);
    window.onpopstate = function (event) {
      history.go(1);
    };
  }

  login() {
    this.loginService.getUserbyLoginName(this.loginForm.value.username, this.loginForm.value.password)
      .subscribe(x => {
        
        this.user = x;

        this.auth.sendToken(this.user)
        this.myRoute.navigate(["afterlogin"]);

      },
        error  =>  this.toastr.error("UserName and Password doesnot match"));
  }


}
