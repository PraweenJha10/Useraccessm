import { Component, OnInit } from '@angular/core';
import { UserGroup, UserRoleGroupName } from '../shared/models/user-role-group-name.model';
import { UserRoleGroupNameService } from '../shared/services/user-role-group-name.service';
import { UserRoleGroupAssign } from '../shared/models/UserRoleGroupAssign.model';
import { ToastrService } from 'ngx-toastr';


@Component({
  selector: 'app-managegroup',
  templateUrl: './managegroup.component.html',
  styleUrls: ['./managegroup.component.css']
})
export class ManagegroupComponent implements OnInit {
  userrolegroup: UserRoleGroupAssign;

  UserRoleGroupNameList: UserRoleGroupName[] = [];
  userId: number;
  constructor(private toastr: ToastrService, private userRoleGroupNameService: UserRoleGroupNameService) { }

  ngOnInit() {

    this.userRoleGroupNameService.getUserRoleDetails(+localStorage.getItem("LoggedInUser"))
      .subscribe(x => {
        this.userrolegroup = x;       
        this.userId = +localStorage.getItem("LoggedInUser");
      });
  }

  CheckboxChange(GroupId: number, $event) {
    this.userrolegroup.Groups.filter(c => c.GroupId === GroupId)[0].IsActive = $event.checked;
  }

  submit() {
    this.UserRoleGroupNameList.splice(0, this.UserRoleGroupNameList.length);

    this.userrolegroup.Groups.forEach(element => {
      this.UserRoleGroupNameList.push({
        UserRoleGroupId: null,
        UserId: this.userId,
        RoleId: this.userrolegroup.RoleId,
        UserName: '',
        RoleName: this.userrolegroup.RoleName,
        GroupId: element.GroupId,
        GroupName: element.GroupName,
        IsActive: element.IsActive
      });
    });


    this.userRoleGroupNameService.addUpdateUserRoleGroupMapping(this.UserRoleGroupNameList).subscribe(() => this.toastr.success("User Groups Updated successfully"));



  }

}
