import { Component, OnInit } from '@angular/core';
import { AuthService } from '../auth.service';
import { LoginService } from '../shared/services/login.service';

@Component({
  selector: 'app-afterlogin',
  templateUrl: './afterlogin.component.html',
  styleUrls: ['./afterlogin.component.css']
})
export class AfterloginComponent implements OnInit {

userName : any;

  constructor(private auth : AuthService) { }

  ngOnInit() {

   this.userName= this.auth.getUserName();
  }

}
