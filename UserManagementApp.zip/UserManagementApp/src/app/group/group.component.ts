import { Component, OnInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { Group } from '../shared/models/group.model';
import { GroupService } from '../shared/services/group.service';
@Component({
  selector: 'app-group',
  templateUrl: './group.component.html',
  styleUrls: ['./group.component.css']
})
export class GroupComponent implements OnInit {
  
 group : Group;
 isDuplicateGroup : boolean = true;
  constructor(private toastr: ToastrService,private groupservice : GroupService) { }

  ngOnInit() {
   this.reset();
  }
  reset(){
    this.group = {
      GroupId : null,
      GroupName : ''
    }
  }
  addGroup() {
    this.groupservice.IsGroupExists(this.group.GroupName).subscribe(x=>{

      if(!x)
      {
        this.groupservice.postGroup(this.group).subscribe(()=> {
          this.reset();
          this.toastr.success("Group added successfully");}
        );
      
      }
      else
      this.toastr.error("Group Name already exists");
    });
    
    
   
  }

}
