import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { LoginService } from './shared/services/login.service';
import { User } from './shared/models/user.model';

@Injectable()
export class AuthService {
  user: User = {
    LoginName: '',
    RoleName: '',
    RoleId: null,
    UserId: null,
    UserName: '',
    UserType: ''

  };
  type: string;
  constructor(private myRoute: Router, private loginService: LoginService) { }

  sendToken(token: User) {
    this.user = token;
    localStorage.setItem("LoggedInUser", token.UserId.toString());
  }

  getToken() {

    return localStorage.getItem("LoggedInUser")
  }

  getUserName() {
    return this.user.UserName;
  }

  isLoggednIn() {
    if (this.user.UserType == "User") {
      return this.getToken();
    }

  }

  isAdminLoggedIn() {
    if (this.user.UserType == "Admin") {
      return this.getToken();
    }
  }

  isAnyLoggedIn() {
    if (this.user.UserType == "Admin" || this.user.UserType == "User") {
      return this.getToken();
    }
  }

  logout() {
    localStorage.removeItem("LoggedInUser");
    this.myRoute.navigate(["login"]);
  }

}
