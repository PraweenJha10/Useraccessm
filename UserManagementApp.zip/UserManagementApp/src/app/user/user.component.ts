import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, FormControl, Validators, Form } from '@angular/forms';
import { UserService } from '../shared/services/user.service';
import { User } from '../shared/models/user.model';
import { ToastrService } from 'ngx-toastr';
@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {
  userTypes: string[] = ["Admin", "User"];
  userForm: FormGroup;
  showProgress: boolean = false;
  user: User;
  constructor(private fb: FormBuilder, private userService: UserService, private toastr: ToastrService) {
    this.userForm =
      this.fb.group({
        UserName: new FormControl('', [Validators.required]),
        LoginName: new FormControl('', [Validators.required]),
        Password: new FormControl('', [Validators.required]),
        UserType: new FormControl('', [Validators.required]),
      });

  }
  onReset(UsersForm: FormGroup) {

  }
  ngOnInit() {

  }
  onSubmit(form: FormGroup) {
    this.user = form.value;
    this.userService.isUserExist(form.value.LoginName).subscribe(x => {
      if (!x) {
        this.userService.AddUser(this.user).subscribe();
        this.toastr.success("User added successfully");
        this.userForm.reset();
      }
      else
        this.toastr.error("User Name already exists");
    });

  }
}