import { Component, OnInit } from '@angular/core';
import { RoleService } from '../shared/services/role.service';
import { Role } from '../shared/models/role.model';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-role',
  templateUrl: './role.component.html',
  styleUrls: ['./role.component.css']
})
export class RoleComponent implements OnInit {
  role : Role ;
  isDuplicateRole : boolean;
  constructor(private toastr: ToastrService,private roleservice : RoleService) { }

  ngOnInit() {
    this.reset();
  }
  reset(){
    this.role = {
      RoleId : null,
      RoleName : ''
    }
  }

  createRole(){
  
     this.roleservice.IsRoleExists(this.role.RoleName).subscribe(x=>{

      if(!x)
      {
        this.roleservice.postRole(this.role).subscribe(()=>{
          this.reset();
          this.toastr.success("Role added successfully");}
        );
       
      }
      else
      this.toastr.error("Role Name already exists");
    });
    
  }

}
