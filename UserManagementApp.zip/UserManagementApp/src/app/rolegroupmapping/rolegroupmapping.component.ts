import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { RoleGroupService } from '../shared/services/role-group.service';
import { Role } from '../shared/models/role.model';
import { GroupService } from '../shared/services/group.service';
import { Group } from '../shared/models/group.model';
import { RoleGroup } from '../shared/models/RoleGroup.model';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-rolegroupmapping',
  templateUrl: './rolegroupmapping.component.html',
  styleUrls: ['./rolegroupmapping.component.css']
})
export class RolegroupmappingComponent implements OnInit {


  roles: Role[];
  allGroupList: Group[];
  selectedRole = null;
  assignedGroupList: Group[] = [];
  assignedLocalGroupList: Group[] = [];
  rolegrouplist: RoleGroup[] = [];
  groupCheckboxList: any;
  typesOfGroups: any;

  constructor(private routes: Router, private roleGroupService: RoleGroupService, private groupService: GroupService, private toastr: ToastrService) {

  }

  ngOnInit() {
    //Initialize Roles here to get first time.
    this.roleGroupService.getRoleList().subscribe(data => this.roles = data);
    this.groupService.getGroupList().subscribe(data => this.allGroupList = data);
  }

  addGroupToRole(group: Group) {
    if (!this.assignedGroupList.includes(group) && this.selectedRole != null) {
      this.assignedGroupList.slice(0, this.assignedGroupList.length);
      this.assignedGroupList.push(group);
      let index = this.allGroupList.indexOf(group);
      this.allGroupList.splice(index, 1);
    }


  }

  removeGroupFromRole(grp: Group) {

    let index = this.assignedGroupList.indexOf(grp);
    this.assignedGroupList.splice(index, 1);
    this.allGroupList.push(grp);
  }

  OnSelect(role: Role) {
    this.selectedRole = role;
    this.getInActiveGroupsByRole(role.RoleId);
    this.getActiveGroupsByRole(role.RoleId);
  }

  UpdateGroupsToRole() {
    this.rolegrouplist.splice(0, this.rolegrouplist.length);
    this.assignedGroupList.forEach(element => {
      this.rolegrouplist.push({
        RoleGroupId: null,
        RoleId: this.selectedRole.RoleId,
        GroupId: element.GroupId,
        IsActive: true
      });
    });
    this.roleGroupService.updateRoleGroups(this.rolegrouplist).subscribe();
    this.toastr.success("Role updated successfully");

  }

  getActiveGroupsByRole(roleid: number) {
    //service call to fetch groups mapped to the selected role
    this.roleGroupService.getGroupListByRole(roleid).subscribe(x => {
      this.groupCheckboxList = x;
      this.assignedGroupList = this.groupCheckboxList.filter(x => x.IsActive === true);
    });
  }

  getInActiveGroupsByRole(roleid: number) {
    //service call to fetch groups mapped to the selected role
    this.roleGroupService.getGroupListByRole(roleid).subscribe(x => {
      this.groupCheckboxList = x;
      this.allGroupList = this.groupCheckboxList.filter(x => x.IsActive === false);
    });
  }
}

