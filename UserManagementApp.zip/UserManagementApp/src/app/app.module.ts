import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgModule } from '@angular/core';
import {
  MatButtonModule, MatCheckboxModule, MatSidenavModule,
  MatToolbarModule, MatCardModule, MatInputModule, MatMenuModule,
  MatIconModule, MatListModule, MatSelectModule, MatPaginatorModule, MatSortModule, MatFormFieldModule, MatTableModule
} from '@angular/material';
import { Routes, RouterModule } from '@angular/router';

import { AppComponent } from './app.component';
import { SidenavComponent } from './sidenav/sidenav.component';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AuthGuard } from './auth.guard';
import { AuthService } from './auth.service';
import { RolegroupmappingComponent } from './rolegroupmapping/rolegroupmapping.component';
import { GroupComponent } from './group/group.component';
import { UserComponent } from './user/user.component';
import { ToastrModule, ToastrService } from 'ngx-toastr';
import { UserdetailsComponent } from './userdetails/userdetails.component';
import { HttpClientModule } from "@angular/common/http";
import { RoleComponent } from './role/role.component';
import { UserManageComponent } from './user-manage/user-manage.component';
import { ManagegroupComponent } from './managegroup/managegroup.component';
import { UserService } from './shared/services/user.service';
import { RoleGroupService } from './shared/services/role-group.service';
import { RoleService } from './shared/services/role.service';
import { UserRoleMappingComponent } from './user-role-mapping/user-role-mapping.component';
import { AfterloginComponent } from './afterlogin/afterlogin.component';


const app_routes: Routes = [
  { path: '', component: HomeComponent, pathMatch: 'full', canActivate: [AuthGuard] },
  { path: 'login', component: LoginComponent },
  { path: 'assignrole', component: RolegroupmappingComponent, canActivate: [AuthGuard] },
  { path: 'managegroup', component: ManagegroupComponent, canActivate: [AuthGuard] },
  { path: 'userrolegroup', component: UserManageComponent, canActivate: [AuthGuard] },
  { path: 'adduser', component: UserComponent, canActivate: [AuthGuard] },
  { path: 'userdetails', component: UserdetailsComponent, canActivate: [AuthGuard] },
  { path: 'create_group', component: GroupComponent, canActivate: [AuthGuard] },
  { path: 'role', component: RoleComponent, canActivate: [AuthGuard] },
  { path: 'afterlogin', component: AfterloginComponent, canActivate: [AuthGuard] },
  { path: 'home', component: HomeComponent }

]

@NgModule({
  declarations: [
    AppComponent,
    SidenavComponent,
    HomeComponent,
    LoginComponent,
    RolegroupmappingComponent,
    GroupComponent,
    UserComponent,
    UserdetailsComponent,
    RoleComponent,
    UserManageComponent,
    ManagegroupComponent,
    UserRoleMappingComponent,
    AfterloginComponent
  ],
  imports: [
    BrowserModule, MatButtonModule, MatCheckboxModule, MatSidenavModule, BrowserAnimationsModule,
    MatToolbarModule, MatCardModule, MatInputModule, ReactiveFormsModule, MatMenuModule, MatIconModule,
    RouterModule.forRoot(app_routes), FormsModule, MatListModule, ReactiveFormsModule, MatSelectModule,
    ToastrModule.forRoot(), MatSortModule, MatPaginatorModule, MatFormFieldModule, MatTableModule, HttpClientModule

  ],
  providers: [AuthGuard, AuthService, ToastrService, UserService, RoleGroupService, RoleService],
  bootstrap: [AppComponent]
})
export class AppModule { }
