import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { NgForm } from '@angular/forms';
import { RoleGroupService } from '../shared/services/role-group.service';
import { UserService } from '../shared/services/user.service';
import { Role } from '../shared/models/role.model';
import { UserRoleGroupName, UserGroup } from '../shared/models/user-role-group-name.model';
import { UserRoleGroupNameService } from '../shared/services/user-role-group-name.service';
import { User } from '../shared/models/user.model';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-user-role-mapping',
  templateUrl: './user-role-mapping.component.html',
  styleUrls: ['./user-role-mapping.component.css']
})
export class UserRoleMappingComponent implements OnInit {
  groupCheckboxList: any;
  typesOfRoles: any;
  userForm: NgForm;
  selectedRole: Role;
  UserRoleGroupNameList: UserRoleGroupName[] = [];
  RoleName: string;
  value: number;

  constructor(private toastr: ToastrService, private roleGroupService: RoleGroupService, private userRoleGroupNameService: UserRoleGroupNameService
    , private userService: UserService) {

  }

  ngOnInit() {
    this.userService.selectedUser = {
      UserId: null,
      RoleName: '',
      RoleId: null,
      Groups: []
    }

    this.userService.UserName = '';
    this.typesOfRoles = this.getRoles();
  }
  onSubmit(form: NgForm) {
    this.UserRoleGroupNameList.splice(0, this.UserRoleGroupNameList.length);

    this.userService.selectedUser.Groups.forEach(element => {
      this.UserRoleGroupNameList.push({
        UserRoleGroupId: null,
        UserId: this.userService.selectedUser.UserId,
        RoleId: this.userService.selectedUser.RoleId,
        UserName: this.userService.UserName,
        RoleName: this.userService.selectedUser.RoleName,
        GroupId: element.GroupId,
        GroupName: element.GroupName,
        IsActive: element.IsActive,
      });
    });


    this.userRoleGroupNameService.addUpdateUserRoleGroupMapping(this.UserRoleGroupNameList).subscribe(() =>
      this.toastr.success("User Updated successfully"));


    form.reset();
    this.userService.selectedUser.Groups = [];
  }
  CheckboxChange(GroupId: number, $event) {
    this.userService.selectedUser.Groups.filter(c => c.GroupId === GroupId)[0].IsActive = $event.checked;
  }

  getRoles() {
    //service call to fetch roles
    this.roleGroupService.getRoleList().subscribe(x => { this.typesOfRoles = x });
  }



  onSelectRole(role: Role) {
    this.roleGroupService.getGroupNameByRole(role.RoleId).subscribe(x => {
      this.userService.selectedUser.Groups = x;
      this.selectedRole = role;
    });
  }
  rolechanged() {
   
  }

}